
	var mensaje = "¡Bienvenido! \n Esta es tu Mercado de Autos \'AutoMer\' \n Por que estamos \"Siempre contigo\" ";
alert(mensaje);

